#include <iostream>
#include <cstdlib>
#include <fstream>
#include <string>

using namespace std;

typedef struct no_ {  //estrutura do nó (características do carro e endereço do próximo carro)
    string placa;
    string modelo;
    string marca;
    string tipo;
    int ano;
    int km;
    string potencia;
    string combustivel;
    string cambio;
    string direcao;
    string cor;
    int portas;

    struct no_ * prox; 
} no;

no* inicia_lista() {  //nó inicial sem valores para definir a estrutura da sequencia
    no* tmp = new (no);
    tmp->prox = NULL;
    tmp->placa = "0";
    tmp->modelo = "0";
    tmp->marca = "0";
    tmp->tipo = "0";
    tmp->ano = 0;
    tmp->km = 0;
    tmp->potencia = "0";
    tmp->combustivel = "0";
    tmp->cambio = "0";
    tmp->direcao = "0";
    tmp->cor = "0";
    tmp->portas = 0;

    cout << "Lista iniciada"<<endl;
    return tmp; //retorna o endereço desse nó inicial que não entra no relatório
}

void encerra_lista(no * ptlista) {
	no * ant = ptlista->prox;
	no * pont = ant->prox;
        int cont=0;

	while(pont != NULL){ //desaloca todos os nós da lista até o ultimo
            cont++;
            delete(ant);
            ant = pont;
            pont = pont->prox;
	}
	delete(ant); //desaloca o ultimo que parou na repetição
        cont++;
        cout << "-A lista foi removida com "<<cont<<" carros."<<endl;
	
	delete(ptlista); //desaloca o nó inicial
}

void busca_enc(no * ptlista, string placa, no ** ant, no ** pont) { //busca pela placa passada
	*ant = ptlista; //ponteiro anterior a posicao encontrada
	*pont = NULL; //ponteiro que aponta para a posição encontrada, será retornado nulo caso a placa não for encontrada

	no * ptr = ptlista->prox; 
	while (ptr != NULL) {
		if (ptr->placa < placa) { //avança a comparação da placa na lista
			*ant = ptr;
			ptr = ptr->prox;
		} else {
			if (ptr->placa == placa) {
				*pont = ptr; //placa encontrada
			}
			ptr = NULL; //encerra a repetição
		}
	}
}

int insere_enc(no * ptlista, string placa, string modelo, string marca, string tipo, int ano, int km,string potencia,string combustivel,string cambio,string direcao,string cor,int portas){
	int retorno = -1; //Retorna -1 em caso de placa ja existe
	no* ant;
	no* pont;

	busca_enc(ptlista, placa, &ant, &pont); //retonará o endereço de pont caso caso ja exista a placa
	
	if(pont == NULL){ //só funcionará se a busca retornar que não encontrou a placa
		no * ptr = new(no);
		ptr->placa = placa; //são inseridos os parametros passados
                ptr->modelo = modelo;
                ptr->marca = marca;
                ptr->tipo = tipo;
                ptr->ano = ano;
                ptr->km = km;
                ptr->potencia = potencia;
                ptr->combustivel = combustivel;
                ptr->cambio = cambio;
                ptr->direcao = direcao;
                ptr->cor = cor;
                ptr->portas = portas;
                ptr->prox = ant->prox;
                ant->prox = ptr;
		retorno = 0; //Retorna 0 em caso de sucesso
	}
	
	return retorno;
}

int insere_no(no* ptlista) { //le os valores na inserção desejada pelo usuário
    no valor; 

    cout << "Digite Modelo: ";
    cin >> valor.modelo;
    cout << "Digite Marca: ";
    cin >> valor.marca;
    cout << "Digite Tipo: ";
    cin >> valor.tipo;
    cout << "Digite Ano: ";
    cin >> valor.ano;
    cout << "Digite km: ";
    cin >> valor.km;
    cout << "Digite potencia: ";
    cin >> valor.potencia;
    cout << "Digite Combustivel: ";
    cin >> valor.combustivel;
    cout << "Digite Cambio: ";
    cin >> valor.cambio;
    cout << "Digite Direcao: ";
    cin >> valor.direcao;
    cout << "Digite cor: ";
    cin >> valor.cor;
    cout << "Digite Numero de portas: ";
    cin >> valor.portas;
    cout << "Digite Placa: ";
    cin >> valor.placa;
    //insere os valores recebidos na lista
    return insere_enc(ptlista,valor.placa,valor.modelo,valor.marca,valor.tipo,valor.ano,valor.km,valor.potencia,valor.combustivel,valor.cambio,valor.direcao,valor.cor,valor.portas);
}

void imprime(no* ptlista) { //apresenta o relatório da lista
    no * ptr = ptlista->prox;

    int cont = 1;
    cout << "Estado atual da lista:" << endl;
    while(ptr != NULL) {
        cout << "Veiculo " << cont++ << ": "<< ptr->modelo << " " << ptr->marca << " " << ptr->tipo << " " << ptr->ano;
        cout << " " << ptr->km << " " << ptr->potencia << " " << ptr->combustivel << " " << ptr->cambio << " " << ptr->direcao;
        cout << " " << ptr->cor << " " << ptr->portas << " " << ptr->placa << endl ;
        ptr = ptr->prox;
    }
    cout << endl;
}

int leitura(no* ptlista) { //lê o arquivo txt 
    ifstream arquivo;
    string linha;
    no valor;
    int cont = 0;

    arquivo.open ("BD_veiculos.txt");
    if (!arquivo) { //não faz a leitura caso o arquivo não for encontrado
        cout << "Arquivo BD_veiculos.txt não encontrado" << endl;
        return 0;
    }
    
    getline(arquivo, linha);
    getline(arquivo, linha);
    while (!arquivo.eof()) {
        arquivo >> valor.modelo; //passa os valores do arquivo para um nó
        arquivo >> valor.marca;
        arquivo >> valor.tipo;
        arquivo >> valor.ano;
        arquivo >> valor.km;
        arquivo >> valor.potencia;
        arquivo >> valor.combustivel;
        arquivo >> valor.cambio;
        arquivo >> valor.direcao;
        arquivo >> valor.cor;
        arquivo >> valor.portas;
        arquivo >> valor.placa;
        insere_enc(ptlista,valor.placa,valor.modelo,valor.marca,valor.tipo,valor.ano,valor.km,valor.potencia,valor.combustivel,valor.cambio,valor.direcao,valor.cor,valor.portas);
        cont++;
    }
    cout << "Veiculos lidos com sucesso"<<endl;
    
    arquivo.close();
    return 0;
}

no * remove_enc (no * ptlista, string placa){

    no* ant; 
    no* pont; //cria os parametros(endereço passado) para buscar se o nó ja existe

    busca_enc(ptlista, placa, &ant, &pont);   //chamada da função busca (mandando os endereços dos nós parametro)
    if(pont!=NULL)   //nó foi encontrado
    {
        cout <<"placa "<<placa<<" encontrada e excluída\n\n";
        ant->prox = pont->prox;   //o prox anterior assume o valor prox do nó a ser excluido
        return pont;   //retorna o nó a ser excluído como foi pedido
    }
    return NULL;   //nó não foi encontrado
}

void imprimecarro(no * ptr) //função que apresenta as caracteristicas de cada carro
{
    cout << ptr->modelo << " " << ptr->marca << " " << ptr->tipo << " " << ptr->ano;
    cout << " " << ptr->km << " " << ptr->potencia << " " << ptr->combustivel << " " << ptr->cambio << " " << ptr->direcao;
    cout << " " << ptr->cor << " " << ptr->portas << " " << ptr->placa << endl;
}

bool busca_param(no * ptlista, string opt){ //apresnta os dados do carro que tem as caracteristicas desejadas pelo usuario
    no * ptr = ptlista->prox;
    string str; //str é o valor string (nome do modelo por exemplo)
    int in, cont=0;  //in é o valor inteiro (ano do carro por exemplo)
    if(opt=="modelo"){ //caso esse seja o parametro
            cout << "+---------------------------------------------------------+" << endl;
            cout << "Digite o modelo para busca: ";
            cin >> str; //valor é lido pelo usuario
            while(ptr != NULL){
                if(ptr->modelo==str){ //caso o valor seja encontrado na lista
                    cout << "Veiculo " << ++cont << ": ";
                    imprimecarro(ptr);} //dados do carro são apresentados
                ptr = ptr->prox; //avança
            }
            if(cont==0) //apresentado caso a caracteristica não for encontrada nenhuma vez
                cout << "nenhum veículo encontrado!" <<endl;
    }
    else if(opt=="marca"){ //mesmo processo para todas as possibilidades de caracteristicas do carro
            cout << "+---------------------------------------------------------+" << endl;
            cout << "Digite a marca para busca: ";
            cin >> str;
            while(ptr != NULL){
                if(ptr->marca==str){
                    cout << "Veiculo " << ++cont << ": ";
                    imprimecarro(ptr);}
                ptr = ptr->prox;
            }
            if(cont==0)
                cout << "nenhum veículo encontrado!" <<endl;
    }
    else if(opt=="tipo"){
            cout << "+---------------------------------------------------------+" << endl;
            cout << "Digite o tipo do carro para busca: ";
            cin >> str;
            while(ptr != NULL){
                if(ptr->tipo==str){
                    cout << "Veiculo " << ++cont << ": ";
                    imprimecarro(ptr);}
                ptr = ptr->prox;
            }
            if(cont==0)
                cout << "nenhum veículo encontrado!" <<endl;
    }
    else if(opt=="ano"){
            cout << "+---------------------------------------------------------+" << endl;
            cout << "Digite o ano do carro para busca: ";
            cin >> in;
            while(ptr != NULL){
                if(ptr->ano==in){
                    cout << "Veiculo " << ++cont << ": ";
                    imprimecarro(ptr);}
                ptr = ptr->prox;
            }
            if(cont==0)
                cout << "nenhum veículo encontrado!" <<endl;
    }
    else if(opt=="km"){
            cout << "+---------------------------------------------------------+" << endl;
            cout << "Digite a kilometragem para busca: ";
            cin >> in;
            while(ptr != NULL){
                if(ptr->km==in){
                    cout << "Veiculo " << ++cont << ": ";
                    imprimecarro(ptr);}
                ptr = ptr->prox;
            }
            if(cont==0)
                cout << "nenhum veículo encontrado!" <<endl;
    }
    else if(opt=="potencia"){
            cout << "+---------------------------------------------------------+" << endl;
            cout << "Digite a potência para busca: ";
            cin >> str;
            while(ptr != NULL){
                if(ptr->potencia==str){
                    cout << "Veiculo " << ++cont << ": ";
                    imprimecarro(ptr);}
                ptr = ptr->prox;
            }
            if(cont==0)
                cout << "nenhum veículo encontrado!" <<endl;
    }
    else if(opt=="combustivel"){
            cout << "+---------------------------------------------------------+" << endl;
            cout << "Digite o combustível para busca: ";
            cin >> str;
            while(ptr != NULL){
                if(ptr->combustivel==str){
                    cout << "Veiculo " << ++cont << ": ";
                    imprimecarro(ptr);}
                ptr = ptr->prox;
            }
            if(cont==0)
                cout << "nenhum veículo encontrado!" <<endl;
    }
    else if(opt=="cambio"){
            cout << "+---------------------------------------------------------+" << endl;
            cout << "Digite o tipo de câmbio para busca: ";
            cin >> str;
            while(ptr != NULL){
                if(ptr->cambio==str){
                    cout << "Veiculo " << ++cont << ": ";
                    imprimecarro(ptr);}
                ptr = ptr->prox;
            }
            if(cont==0)
                cout << "nenhum veículo encontrado!" <<endl;
    }
    else if(opt=="direcao"){
            cout << "+---------------------------------------------------------+" << endl;
            cout << "Digite o tipo de direção para busca: ";
            cin >> str;
            while(ptr != NULL){
                if(ptr->direcao==str){
                    cout << "Veiculo " << ++cont << ": ";
                    imprimecarro(ptr);}
                ptr = ptr->prox;
            }
            if(cont==0)
                cout << "nenhum veículo encontrado!" <<endl;
    }
    else if(opt=="cor"){
            cout << "+---------------------------------------------------------+" << endl;
            cout << "Digite a cor do carro para busca: ";
            cin >> str;
            while(ptr != NULL){
                if(ptr->cor==str){
                    cout << "Veiculo " << ++cont << ": ";
                    imprimecarro(ptr);}
                ptr = ptr->prox;
            }
            if(cont==0)
                cout << "nenhum veículo encontrado!" <<endl;
    }
    else if(opt=="portas"){
            cout << "+---------------------------------------------------------+" << endl;
            cout << "Digite a quantidade de portas para busca: ";
            cin >> in;
            while(ptr != NULL){
                if(ptr->portas==in){
                    cout << "Veiculo " << ++cont << ": ";
                    imprimecarro(ptr);}
                ptr = ptr->prox;
            }
            if(cont==0)
                cout << "nenhum veículo encontrado!" <<endl;
    }
    else if(opt=="placa"){
            cout << "+---------------------------------------------------------+" << endl;
            cout << "Digite a placa para busca: ";
            cin >> str;
            while(ptr != NULL){
                if(ptr->placa==str){
                    cout << "Veiculo " << ++cont << ": ";
                    imprimecarro(ptr);}
                ptr = ptr->prox;
            }
            if(cont==0)
                cout << "nenhum veículo encontrado!" <<endl;
    }
    return true;
}

void menu() //apresenta os dados do menu
{
    cout << "+----------------------------------+" << endl;
    cout << "+               Menu               +" << endl;
    cout << "+ 1 - Inclusão                     +" << endl;
    cout << "+ 2 - Exclusão                     +" << endl;
    cout << "+ 3 - Buscas                       +" << endl;
    cout << "+ 4 - Relátorio                    +" << endl;
    cout << "+ 0 - Sair                         +" << endl;
    cout << "+----------------------------------+" << endl;
    cout << "Digite qual opção deseja utilizar: ";
}

no * lista1; //lista com os carros
