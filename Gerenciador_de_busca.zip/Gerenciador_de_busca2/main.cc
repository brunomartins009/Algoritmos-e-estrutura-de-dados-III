/*---------------------------------------------------------------
 ∗ UNIFAL − Universidade Federal de Alfenas.
 ∗ BACHARELADO EM CIENCIA DA COMPUTACAO.
 ∗ Trabalho   : Processamento de Imagens com Ponteiros
 ∗ Disciplina : Aeds II
 ∗ Professor  : Paulo Alexandre Bressan
 ∗ Alunos     : Bruno Martins Cordeiro;  Matrícula: 2020.1.08.006
 ∗              Luis Gustavo Silva Piza; Matrícula: 2020.1.08.021
 ∗ Data       : 29/03/2022
 ∗------------------------------------------------------------*/
#include <iostream>
#include <fstream>
#include <string>
#include "function.h"

using namespace std;

int main(void)
{
    int cod;
    char op;
    string placa, carac;
    
    lista1 = inicia_lista(); //lista é iniciada
    leitura(lista1); //arquivo é lido
    imprime(lista1); //apresenta os dados do arquivo
    menu(); //menu de opcoes é apresentado
    scanf("%d", &cod); //opcao desejada do usuario é lida
    while(cod < 0 || cod > 4){ //caso digite uma opcao não existente
        cout << "Código não identificado! Insira novamente: ";
        scanf("%d", &cod);
    }
    while(cod != 0){ //enquanto não seja escolhido sair do programa
        switch (cod) {
            case 1 : //inserção
                cout << "+----------------------------------------------------------+" << endl;
                if (insere_no(lista1)==0)
                    cout << "Veiculo inserido" << endl;
                else cout << "Veiculo já inserido anteriormente" << endl;
            break;

            case 2 : //exclusão
                cout << "+---------------------------------------------------------+" << endl;
                cout << "Digite a placa do veiculo a ser removido: ";
                cin >> placa;
                if(remove_enc(lista1,placa)==NULL)
                    cout << "placa não encontrada"<<endl;
            break;

            case 3 : //busca por parametro
                cout << "+---------------------------------------------------------+" << endl;
                cout << "Digite a característica do carro a ser buscada: ";
                cin >> carac;
                
                while(carac!="placa"&&carac!="modelo"&&carac!="marca"&&carac!="tipo"&&carac!="ano"&&carac!="km"&&carac!="potencia"&&carac!="combustivel"&&carac!="cambio"&&carac!="direcao"&&carac!="cor"&&carac!="portas"){
                    cout << "Característica não identificada! Insira novamente: ";
                    cin >> carac;
                }
                busca_param(lista1, carac);
            break;

            case 4 : //apresentação dos dados da lista
                cout << "+---------------------------------------------------------+" << endl;
                imprime(lista1);
            break;
        } //pergunta após cada operação
        cout << "+-------------------------------------------------------------+" << endl;
        cout << "Realizar outra operação? S ou N: ";
        scanf("%s", &op);
        if(op == 'S' || op == 's') { //caso sim
            menu();
            scanf("%d", &cod);
            while(cod < 0 || cod > 4){
                cout << "Código não identificado! Insira novamente: ";
                scanf("%d", &cod);
            }
        }else{ //encerra o programa
            cod = 0;
        }
    }
    encerra_lista(lista1); //desaloca a lista
    cout << "\n" << endl;
    cout << "Obrigado por utilizar!!" << endl;
    
    
    return 0; //encerra o programa
}