#include <cstdlib>
#include <iostream>
#include "lista.h"
#include <string.h>
#include <string>

using namespace std;

tLista* inicia_lista() {
    tLista* tmp = new (tLista);
    tmp->tam = 0;
    tmp->inicio = NULL;
    tmp->fim = NULL;
    return tmp;
}

void insereBin(Tree** raiz, no * novo){
    if (*raiz == NULL){
        *raiz = new(Tree);
        (*raiz)->esquerdo = NULL;
        (*raiz)->direito = NULL;
        (*raiz)->info = novo;
    }else{
        no * aux = (*raiz)->info;
  
        if(novo->placa < aux->placa){

          insereBin(&(*raiz)->esquerdo, novo);
        }

        if(novo->placa > aux->placa){

          insereBin(&(*raiz)->direito, novo);
        }
    }
}

int alturaBin(Tree * raiz){
   if (raiz == NULL) 
      return -1;
   else {
      int he = alturaBin(raiz->esquerdo);
      int hd = alturaBin(raiz->direito);
      if (he < hd) return hd + 1;
      else return he + 1;
   }
}

int maior_altura(int a, int b){
    return (a > b)? a: b;
}


int altura_no(Tree * tmp){
    if(tmp == NULL){
        return -1;
    }else{
        return tmp->altura;
    }
}
  

bool arvoreVazia(Tree * raiz){
    if(raiz == NULL){ 
        return true;
    }else{
        return false;
    }
}


Tree *  inserir_AVL(Tree** raiz, no * novo){
    if((*raiz) == NULL){
        *raiz = new(Tree);
        (*raiz)->info = novo;
        (*raiz)->esquerdo = NULL;
        (*raiz)->direito = NULL;
        (*raiz)->altura = 0;
        return (*raiz);
    }
    else{
        no * aux = (*raiz)->info;
        if( novo->placa < aux->placa){
            (*raiz)->esquerdo = inserir_AVL(&(*raiz)->esquerdo, novo);
        }
        else if(novo->placa > aux->placa){
            (*raiz)->direito = inserir_AVL(&(*raiz)->direito, novo);
        }
        else{
            cout << "    Falha na inserção    " << endl;
            return (*raiz);
        }
    }
    
    (*raiz)->altura = 1 + maior_altura(altura_no((*raiz)->esquerdo), altura_no((*raiz)->direito));
    
    (*raiz) = balancear(*raiz);
    
    return (*raiz);
}
Tree * rotacao_esquerda(Tree * raiz){
    Tree *y, *f;
    y = raiz->direito;
    f = y->esquerdo;
    
    y->esquerdo = raiz;
    raiz->direito = f;
    
    raiz->altura = maior_altura(altura_no(raiz->esquerdo), altura_no(raiz->direito)) +1;
    y->altura = maior_altura(altura_no(y->esquerdo), altura_no(y->direito)) +1;
    
    return y;
}

Tree * rotacao_direita(Tree * raiz){
    Tree *y, *f;
    y = raiz->esquerdo;
    f = y->direito;
    
    y->direito = raiz;
    raiz->esquerdo = f;
    
    raiz->altura = maior_altura(altura_no(raiz->esquerdo), altura_no(raiz->direito)) +1;
    y->altura = maior_altura(altura_no(y->esquerdo), altura_no(y->direito)) +1;

    return y;
}

Tree * dupla_esquerda(Tree * raiz){
    raiz->direito = rotacao_direita(raiz->direito);
    return rotacao_esquerda(raiz);
}

Tree * dupla_direita(Tree * raiz){
    raiz->esquerdo = rotacao_esquerda(raiz->esquerdo);
    return rotacao_direita(raiz);
}


int fator_balanceamento(Tree * tmp){
    if(tmp){
        return(altura_no(tmp->esquerdo) - altura_no(tmp->direito));
    }else{
        return 0;
    }
}

Tree * balancear(Tree * raiz){
    int num = fator_balanceamento(raiz);
    
    
    if(num < -1 && fator_balanceamento(raiz->direito) <= 0){

        raiz = rotacao_esquerda(raiz);        
    }else if(num > 1 && fator_balanceamento(raiz->esquerdo) >= 0){ 

        raiz = rotacao_direita(raiz);
    }else if(num > 1 && fator_balanceamento(raiz->esquerdo) < 0 ){

        raiz = dupla_direita(raiz);
    }else if(num < -1 && fator_balanceamento(raiz->direito) > 0){

        raiz = dupla_esquerda(raiz);
    }
    
    return raiz;
}
 
Tree * busca (tLista * lista1, string parametro1, string parametro2, int opcao){
    no * pont = lista1->inicio;
    int tamanho = lista1->tam;
    

    if (opcao == 1){
        Tree * binaria1 = NULL;
        while(tamanho > 0){
            if(procura(parametro1, pont)){    
                if(procura(parametro2, pont)){
                    insereBin(&binaria1, pont);
                }
            }
            pont = pont->prox;
            tamanho--;
        }
        return binaria1;
        
    }
    else{
        Tree * avl = NULL;
        while(tamanho > 0){
            if(procura(parametro1, pont)){    
                if(procura(parametro2, pont)){
                    inserir_AVL(&avl, pont);
                }
            }
            pont = pont->prox;
            tamanho--;
        }
        return avl;
    }
}

bool procura (string busca, no * pont){
  int i = 0;
  while (busca[i]!='\0'){
      busca[i] = toupper(busca[i]);
      i++;
  }

  i = 0;
  while(pont->marca[i]!='\0'){
      pont->marca[i] = toupper(pont->marca[i]);
      i++;
  }
  
  i = 0;
  while(pont->tipo[i]!='\0'){
      pont->tipo[i] = toupper(pont->tipo[i]);
      i++;
  }
    
  i = 0;
  while(pont->ano[i]!='\0'){
      pont->ano[i] = toupper(pont->ano[i]);
      i++;
  }
  
  i = 0;
  while(pont->km[i]!='\0'){
      pont->km[i] = toupper(pont->km[i]);
      i++;
  }

  i = 0;
  while(pont->cavalosC[i]!='\0'){
      pont->cavalosC[i] = toupper(pont->cavalosC[i]);
      i++;
  }
  
  i = 0;
  while(pont->combustivel[i]!='\0'){
      pont->combustivel[i] = toupper(pont->combustivel[i]);
      i++;
  }

  i = 0;
  while(pont->cambio[i]!='\0'){
      pont->cambio[i] = toupper(pont->cambio[i]);
      i++;
  }
  
  i = 0;
  while(pont->direcao[i]!='\0'){
      pont->direcao[i] = toupper(pont->direcao[i]);
      i++;
  }

  i = 0;
  while(pont->cor[i]!='\0'){
      pont->cor[i] = toupper(pont->cor[i]);
      i++;
  }

  i = 0;
  while(pont->portas[i]!='\0'){
      pont->portas[i] = toupper(pont->portas[i]);
      i++;
  }

  i = 0;
  while(pont->modelo[i]!='\0'){
      pont->modelo[i] = toupper(pont->modelo[i]);
      i++;
  }
 
  i = 0;
  while(pont->placa[i]!='\0'){
      pont->placa[i] = toupper(pont->placa[i]);
      i++;
  }
  
    if(busca == pont->marca){
        return true;
    }
    if(busca == pont->tipo){
        return true;                    
    }
    if(busca == pont->ano){
        return true;                
    }
    if(busca == pont->km){
        return true;
    }
    if(busca == pont->cavalosC){
        return true;                
    }
    if(busca == pont->combustivel){
        return true;                
    }
    if(busca == pont->cambio){
        return true;                
    }
    if(busca == pont->direcao){
        return true;                
    }
    if(busca == pont->cor){
        return true;                
    }
    if(busca == pont->portas){
        return true;                
    }
    if(busca == pont->placa){
        return true;                
    }
    if(busca == pont->modelo){
        return true;                
    }
    return false;   
}

void preOrdem(Tree * raiz){
    cout << "  Placa...: " << raiz->info->placa;
    cout << "  Modelo..: " << raiz->info->modelo<< endl;
    if(raiz->esquerdo != NULL){
        preOrdem(raiz->esquerdo);
    }
    if(raiz->direito != NULL){
        preOrdem(raiz->direito);
    }
}


void exibe(Tree * raiz){
    if(arvoreVazia(raiz)){
        
        cout << endl;
        cout << "      Veículo não encontrado      "<< endl;
        cout << endl;        
    } else {
        raiz->altura = alturaBin(raiz); 
        cout << "   Altura da árvore --> "<< raiz->altura << "       " << endl;
        cout << endl;
        preOrdem(raiz);
        cout << endl;    
      }
}

Tree * libera_arvore(Tree * raiz){
    if (!arvoreVazia(raiz)){
        libera_arvore(raiz->esquerdo);
        libera_arvore(raiz->direito);
        free(raiz);
    }
    return NULL;
}

void relatorio(tLista * lista1){
	no * ptr = lista1->inicio;
        cout << "  ++++++++++++++++++++++++++++++++++++++" << endl;
        cout << "  +       ESTADO ATUAL DA LISTA:       +" << endl;
        cout << "  +------------------------------------+" << endl;
        cout << "  +      PLACA      |      MODELO      +" << endl;
        cout << "  ++++++++++++++++++++++++++++++++++++++" << endl;
	while(ptr != NULL){
          cout << "  +\t\t"<<"["<<ptr->placa <<"]\t|\t ["<< ptr->modelo << "]" << "\t\t+  " << endl;

        ptr = ptr->prox;
	}
        cout << "  +                                   +"<< endl;
        cout << "  +     Quantidade de Carros  = " << lista1->tam << "    |"<< endl;
        cout << "  +                                   +"<< endl;
        cout << "  +++++++++++++++++++++++++++++++++++++" << endl;
        cout << endl;
}

bool busca_lista(tLista * lista1, no * novo){
    no * ant = lista1->inicio;
    no * pont = lista1->inicio;
    while (pont != NULL){
        if (pont->placa == novo->placa){
            return true;
        }
        else{
            ant = pont;
            pont = pont->prox; 
        }
    }
    return false;
}
 
bool incluir (no * novo, tLista * lista1){
    no * ant = lista1->inicio;
    no * ptr = lista1->inicio;
    if (lista1->tam == 0){
        //lista1->lista = new(no);
        lista1->inicio = novo;
        lista1->fim = novo;
        lista1->inicio->prox = NULL;
        lista1->tam++;
        return true;
    }
    if(busca_lista(lista1, novo)){
        return false;
    }
    lista1->tam++;
    
    lista1->fim->prox = novo;
    lista1->fim = novo;

    return true;
}

tLista * encerra_lista(tLista * lista1) {
    no * ant = lista1->inicio;
    no * pont = lista1->inicio;
    while(ant != NULL){
	pont = ant->prox;
	delete(ant);
	ant = pont;
    }
    delete(lista1);
    return NULL;
}

no * remover_lista(string busca1, tLista * lista1){
    no * ant = lista1->inicio;
    no * pont= lista1->inicio;
    if(lista1->tam == 0){
        cout << "  Não foi possível remover o veículo de placa ("<< busca1 <<") , pois a Lista está vazia." <<endl;
        return NULL;
    }
    while(pont != NULL){
        if(pont->placa == busca1){
            if(pont->placa == lista1->inicio->placa){
                lista1->inicio = pont->prox;
            }
            if(pont->placa == lista1->fim->placa){
                lista1->fim = ant;
            }
            if(lista1->tam==1){
                lista1->inicio = NULL;
                lista1->fim = NULL;
                ant->prox = NULL;
                ant = NULL;
                pont->prox = NULL;
                lista1->tam--;

                return pont;
            }
            else{
                ant->prox = pont->prox;
                pont->prox = NULL;
                lista1->tam--;
            }         

            return pont;
        }
        ant = pont;
        pont = ant->prox;
    }
    cout << "  Não foi possível remover o veículo de placa ("<< busca1 <<"), tente novamente." << endl;
    return NULL;
    
}