/*---------------------------------------------------------------
 ∗ UNIFAL − Universidade Federal de Alfenas.
 ∗ BACHARELADO EM CIENCIA DA COMPUTACAO.
 ∗ Trabalho   : Busca de Carros, Vans e Utilitários com Árvores
 ∗ Disciplina : Aeds II
 ∗ Professor  : Paulo Alexandre Bressan
 ∗ Alunos     : Bruno Martins Cordeiro;  Matrícula: 2020.1.08.006
 ∗              Luis Gustavo Silva Piza; Matrícula: 2020.1.08.021
 ∗ Data       : 12/04/2022
 ∗------------------------------------------------------------*/

#include <cstdlib>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <string>
#include <ctype.h> 
#include <locale.h>
#include <stdio.h>

#include "lista.h"

using namespace std;

tLista* mainLista;

int main(int argc, char** argv) {
  setlocale(LC_ALL, "Portuguese");
    int cod = 0;
    int cod2 = 0;
  
    string ctr1, ctr2;
    
    bool arvBin = false, arvAVL = false;
    
    bool arquivo = false;
    
    
    Tree * Binaria = NULL;
    Tree *AVL = NULL;
    
    ifstream file1 ("BD_veiculos.txt");
    if (file1.is_open()){
        mainLista = inicia_lista();
      string word;
        for(int i = 0; i < 13; i++){
      file1 >> word;
        }
        word = "";   
      
        while (!file1.eof()){
            no * novo = new no();
          
            file1 >> novo->modelo;
            file1 >> novo->marca;
            file1 >> novo->tipo;
            file1 >> novo->ano;
            file1 >> novo->km;
            file1 >> novo->cavalosC;
            file1 >> novo->combustivel;
            file1 >> novo->cambio;
            file1 >> novo->direcao;
            file1 >> novo->cor;
            file1 >> novo->portas;
            file1 >> novo->placa;
          
            novo->prox = NULL;
            incluir (novo, mainLista);
            arquivo = 1;
        }
        file1.close();
    }
    else{
        cout << "Arquivo não disponível."<<endl;
    }
    
    if(arquivo == 1){
        do{
            cout << "  ++++++++++++++++++++++++++++++++++++" << endl;
            cout << "  +           MENU DE OPÇÕES         +" << endl;
            cout << "  ++++++++++++++++++++++++++++++++++++" << endl;
            cout << "  + 1 - Inserir veículo              +" << endl;
            cout << "  + 2 - Remover veículo              +" << endl;
            cout << "  + 3 - Buscar                       +" << endl;
            cout << "  + 4 - Relatório                    +" << endl;
            cout << "  + 5 - Relatório das árvores        +" << endl;
            cout << "  + 0 - Sair                         +" << endl;
            cout << "  ++++++++++++++++++++++++++++++++++++" << endl;

            cout << endl;
            cout << " Digite qual da opção desejada: ";
            cin >> cod;

            system("clear||cls");

            while ( cod < 0 || cod > 5){
                cout << " Valor inválido! Digite novamente: ";
                cin >> cod;
            }

            if ( cod == 0){
                if (arvBin){
                    libera_arvore(Binaria);
                    arvBin = false;
                }
                if (arvAVL){
                    libera_arvore(AVL);
                    arvAVL = false;
                }
                mainLista = encerra_lista(mainLista);
            }

            if(cod == 1){
                no * novo = new no();
                cout << endl;
                cout << "\r" " Insira os dados do novo veículo: " << endl;
                cout << endl;
                cout << " Digite o modelo: ";
                cin >> novo->modelo;

                cout << " Digite a marca: ";
                cin >> novo->marca;

                cout << " Digite o tipo: ";
                cin >> novo->tipo;

                cout << " Digite o ano: ";
                cin >> novo->ano;

                cout << " Digite a KM: ";
                cin >> novo->km;

                cout << " Digite a Potência do Motor: ";
                cin >> novo->cavalosC;

                cout << " Digite o combustível: ";
                cin >> novo->combustivel;

                cout << " Digite o câmbio: ";
                cin >> novo->cambio;

                cout << " Digite a direção: ";
                cin >> novo->direcao;

                cout << " Digite a cor: ";
                cin >> novo->cor;

                cout << " Digite a quantidade de portas: ";
                cin >> novo->portas;

                cout << " Digite a placa: ";
                cin >> novo->placa;

                novo->prox = NULL;
                if (incluir (novo, mainLista)){
                    cout << endl;
                    cout << "  Veículo foi inserido com sucesso! " << endl;
                    cout << endl;
                }
                else{
                    cout << endl;
                    cout << "     O veículo já está existe na Lista   " << endl;
                    cout << endl;
                }

              system("clear||cls");
            }

            if(cod == 2){
                cout << " Digite a placa do veículo que deseja remover: ";
                cin >> ctr1;  
                  
                no * deletar;
                deletar = remover_lista(ctr1, mainLista);
                if(deletar != NULL){
                    cout << endl;
                    cout << " O veículo de placa (" << deletar->placa << ") foi removido com sucesso! " << endl;
                    cout << endl;
                }
            }
 
            if(cod == 3){
                cout << endl;
                cout << "         Qual tipo de árvore usar?        " << endl;
                cout << endl;
                cout << "            1 - Árvore Binária            " << endl;
                cout << "            2 - Árvore AVL                " << endl;
                cout << endl;
                cout << " Digite a opção de armazenamento desejada: ";
                cin >> cod2;
                if (cod2 > 0 && cod2 <= 2){
                   
                if (arvBin){
                    libera_arvore(Binaria);
                    arvBin = false;
                }
                if (arvAVL){
                    libera_arvore(AVL);
                    arvAVL = false;
                }
                if (cod2 == 1){              
                    cout <<endl;
                    cout << " Exemplo: Se deseja buscar por carros da cor Preto a câmbio Manual digite: 'Preto' no primeiro critério e 'Manual' no segundo critério" << endl;
                    cout <<endl;
                    cout << " Digite o PRIMEIRO critério de busca desejada: ";
                    cin >> ctr1; 
                    cout << endl;
                    cout << " Digite o SEGUNDO critério de busca desejada: ";
                    cin >> ctr2;
                    
                    Binaria = busca (mainLista, ctr1, ctr2, cod);
                    arvBin = true;
                }
                else if(cod2 == 2) {
                    cout <<endl;
                    cout << " Exemplo: Se deseja buscar por carros da cor Branco a câmbio Automático digite: 'Branco' no primeiro critério e 'Automático' no segundo critério" << endl;
                    cout << " Digite o primeiro critério de busca desejada: ";
                    cin >> ctr1;
                    cout << endl;
                    
                    cout << " Digite o segundo critério de busca desejada: ";
                    cin >> ctr2;
                    
                    AVL = busca (mainLista, ctr1, ctr2, cod);
                    arvAVL = true;
                }
                cout << endl;
                cout << "    Busca realizada!" << endl;
                cout << endl;
                }
            }
            if(cod == 4){
                cout << endl;
                relatorio(mainLista);
            }
            if(cod == 5){
                cout<<endl;
                if(!arvBin && !arvAVL){
                    cout << "     Nenhuma árvore foi utilizada   " << endl;
                }
                if (arvBin){
                    cout << endl;
                    cout << "                      Árvore Binário:                      "<< endl;
                    cout << endl;
                    exibe(Binaria);
                    cout<<endl;
                   
                }
                cout << endl;
                if (arvAVL){
                    cout << endl;
                    cout << "                       Árvore AVL:                       "<< endl;
                    cout << endl;
                    exibe(AVL);
                    cout<<endl;
                }
            }
        } while (cod != 0);
    }
    return 0;
}